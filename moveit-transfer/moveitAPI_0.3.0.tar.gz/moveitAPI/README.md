# moveitAPI

[MOVEit API Docs](https://docs.ipswitch.com/MOVEit/Transfer2019_1/API/Rest/#_overview)

### Installation
`devtools::install_github("Allegheny-CountyStats/moveitAPI")`

### Authentication

`tokens <- authMoveIt("moveit.hosturl.com", "grant_type=password&username=YOUR_USERNAME&password=YOUR_PASSWORD")`
